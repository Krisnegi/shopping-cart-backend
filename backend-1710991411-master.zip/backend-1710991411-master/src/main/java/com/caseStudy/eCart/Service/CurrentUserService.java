package com.caseStudy.eCart.Service;

import com.caseStudy.eCart.Repository.UserRepository;
import com.caseStudy.eCart.model.Cart;
import com.caseStudy.eCart.model.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.Optional;

@Service
public class CurrentUserService {
    @Autowired
    private UserRepository userRepository;

   /* public Optional<Users> CurrentUser(Principal principal){
        String email=principal.getName();
        return userRepository.findByEmail(email);
    }*/
    public int getuserid(Principal principal)
    {
        String email=principal.getName();
        int id=userRepository.findByEmail(email).get().getId();
        return id;
    }
    /*public Long getuserrole(Principal principal)
    {
        return userRepository.findByEmail(principal.getName()).get().getRole().getRoleid();
    }
    public Optional<Users> getuserprofile(Principal principal)
    {
        return userRepository.findByEmail(principal.getName());
    }
    public ResponseEntity<?> checkdetails(Users user, Principal principal)
    {
        Optional<Users> usercheck=userRepository.findByEmail(principal.getName());
        Optional<Users> usercheckinfo=userRepository.findByEmail(user.getEmail());
        if(usercheckinfo.isPresent() & usercheckinfo.get().getEmail() != usercheck.get().getEmail()){
            HttpHeaders responseHeaders=new HttpHeaders();
        }
        else{
            Cart cart=new Cart();
            cart.setItems(product);
            cart.setUser(user);
            cart.setQuantity(1);
            cartRepsoitory.save(cart);
        }
    }*/
}
